/* =============================
   GENERATE RESUME PREVIEW
============================= */

function generateResume(){

const name = document.getElementById("name").value
const email = document.getElementById("email").value
const skills = document.getElementById("skills").value
const education = document.getElementById("education").value
const experience = document.getElementById("experience").value
const projects = document.getElementById("projects").value

if(!name || !email){
alert("Please enter at least name and email")
return
}

const preview = document.getElementById("resumePreview")

/* Convert skills into list */

const skillsList = skills
.split(",")
.map(skill => `<li>${skill.trim()}</li>`)
.join("")

preview.innerHTML = `

<div class="resume">

<h2>${name}</h2>

<p><b>Email:</b> ${email}</p>

<h3>Skills</h3>
<ul>${skillsList}</ul>

<h3>Education</h3>
<p>${education}</p>

<h3>Experience</h3>
<p>${experience}</p>

<h3>Projects</h3>
<p>${projects}</p>

</div>

`

}


/* =============================
   DOWNLOAD RESUME AS PDF
============================= */

function downloadResume(){

const element = document.getElementById("resumePreview")

if(!element.innerHTML){
alert("Please generate resume first")
return
}

try{

html2pdf()
.from(element)
.set({
margin:1,
filename:"resume.pdf",
html2canvas:{scale:2},
jsPDF:{unit:"in",format:"letter",orientation:"portrait"}
})
.save()

}
catch(error){

alert("Failed to generate PDF")

}

}