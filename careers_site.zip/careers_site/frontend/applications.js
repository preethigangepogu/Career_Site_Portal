async function loadApplications(){

const res = await fetch("http://localhost:5000/applications")

const applications = await res.json()

const container = document.getElementById("applicationsContainer")

container.innerHTML=""

if(applications.length === 0){

container.innerHTML="<p>No applications yet.</p>"

return

}

applications.forEach(app=>{

const div = document.createElement("div")

div.className="jobCard"

div.innerHTML=`

<h3>Applicant: ${app.name}</h3>
<p><b>Email:</b> ${app.email}</p>
<p><b>Job ID:</b> ${app.jobId}</p>

`

container.appendChild(div)

})

}

loadApplications()