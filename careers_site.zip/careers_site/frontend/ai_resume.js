/* =============================
   ANALYZE RESUME
============================= */

async function analyzeResume(){

const text = document.getElementById("resumeText").value.toLowerCase()

if(!text){
alert("Please paste your resume text first")
return
}

const knownSkills = [
"javascript","react","node","python","java","html","css",
"mongodb","sql","aws","docker","git","c++","machine learning"
]

let foundSkills = []

knownSkills.forEach(skill=>{
if(text.includes(skill)){
foundSkills.push(skill)
}
})

/* Display detected skills */

document.getElementById("skills").innerHTML = 
foundSkills.length ? foundSkills.join(", ") : "No skills detected"

/* Recommend missing skills */

const recommended = knownSkills.filter(skill => !foundSkills.includes(skill))

document.getElementById("recommend").innerHTML = 
recommended.slice(0,5).join(", ")

/* Find matching jobs */

matchJobs(foundSkills)

}


/* =============================
   MATCH JOBS BASED ON SKILLS
============================= */

async function matchJobs(skills){

const res = await fetch("http://localhost:5000/jobs")
const jobs = await res.json()

const container = document.getElementById("jobMatch")

container.innerHTML = ""

let matches = []

jobs.forEach(job=>{

if(!job.description) return

const desc = job.description.toLowerCase()

const matched = skills.some(skill => desc.includes(skill))

if(matched){
matches.push(job)
}

})

/* Remove duplicates */

matches = [...new Map(matches.map(job => [job.id, job])).values()]

if(matches.length === 0){
container.innerHTML = "<p>No matching jobs found.</p>"
return
}

/* Display matching jobs */

matches.forEach(job=>{

const div = document.createElement("div")

div.className = "jobCard"

div.innerHTML = `
<h3>${job.title}</h3>
<p><b>Company:</b> ${job.company}</p>
<p><b>Location:</b> ${job.location}</p>
`

container.appendChild(div)

})

}