/* =============================
   JOB RECOMMENDATION ENGINE
============================= */

async function recommendJobs(){

const skillInput = document.getElementById("userSkills").value

if(!skillInput){
alert("Please enter your skills")
return
}

/* Convert skills into array */

const skills = skillInput
.toLowerCase()
.split(",")
.map(skill => skill.trim())
.filter(skill => skill !== "")

try{

const res = await fetch("http://localhost:5000/jobs")
const jobs = await res.json()

let matches = []

jobs.forEach(job=>{

if(!job.description) return

const description = job.description.toLowerCase()

let score = 0

skills.forEach(skill=>{
if(description.includes(skill)){
score++
}
})

if(score > 0){
matches.push({
job: job,
score: score
})
}

})

/* Sort jobs by highest match score */

matches.sort((a,b)=> b.score - a.score)

displayJobs(matches)

}
catch(error){

console.error("Recommendation error:", error)
alert("Failed to load job recommendations")

}

}


/* =============================
   DISPLAY MATCHING JOBS
============================= */

function displayJobs(matches){

const container = document.getElementById("recommendedJobs")

container.innerHTML = ""

if(matches.length === 0){
container.innerHTML = "<p>No matching jobs found.</p>"
return
}

matches.forEach(item=>{

const job = item.job

const div = document.createElement("div")

div.className = "jobCard"

div.innerHTML = `
<h3>${job.title}</h3>
<p><b>Company:</b> ${job.company}</p>
<p><b>Location:</b> ${job.location}</p>
<p><b>Match Score:</b> ${item.score}</p>
`

container.appendChild(div)

})

}
