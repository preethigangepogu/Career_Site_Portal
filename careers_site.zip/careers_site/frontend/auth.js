/* =============================
   REGISTER USER
============================= */

async function register() {

const name = document.getElementById("name").value;
const email = document.getElementById("email").value;
const password = document.getElementById("password").value;
const role = document.getElementById("role").value;

if (!name || !email || !password || !role) {
alert("Please fill all fields");
return;
}

try {

const res = await fetch("http://localhost:5000/register", {

method: "POST",

headers: {
"Content-Type": "application/json"
},

body: JSON.stringify({
name,
email,
password,
role
})

});

const data = await res.json();

alert("Account created successfully!");

window.location = "login.html";

} catch (error) {

alert("Registration failed");

}

}


/* =============================
   LOGIN USER
============================= */

async function login() {

const email = document.getElementById("email").value;
const password = document.getElementById("password").value;

if (!email || !password) {
alert("Please enter email and password");
return;
}

try {

const res = await fetch("http://localhost:5000/login", {

method: "POST",

headers: {
"Content-Type": "application/json"
},

body: JSON.stringify({ email, password })

});

const data = await res.json();

if (data.error) {
alert(data.error);
return;
}

/* Save user role */

localStorage.setItem("userRole", data.role);

/* Redirect based on role */

if (data.role === "company") {

window.location = "dashboard.html";

} else {

window.location = "index.html";

}

} catch (error) {

alert("Login failed");

}

}