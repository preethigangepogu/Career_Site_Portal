/* =============================
   PAGE NAVIGATION
============================= */

function showHome() {

document.getElementById("home").classList.remove("hidden");
document.getElementById("jobs").classList.add("hidden");
document.getElementById("postJob").classList.add("hidden");

}

function showJobs() {

document.getElementById("home").classList.add("hidden");
document.getElementById("jobs").classList.remove("hidden");
document.getElementById("postJob").classList.add("hidden");

loadJobs();

}

function showPostJob() {

document.getElementById("home").classList.add("hidden");
document.getElementById("jobs").classList.add("hidden");
document.getElementById("postJob").classList.remove("hidden");

}


/* =============================
   LOAD JOBS FROM BACKEND
============================= */

async function loadJobs() {

const res = await fetch("http://localhost:5000/jobs");
const jobs = await res.json();

const container = document.getElementById("jobsContainer");

container.innerHTML = "";

jobs.forEach(job => {

const div = document.createElement("div");

div.className = "jobCard";

div.innerHTML = `
<h3>${job.title}</h3>
<p><b>Company:</b> ${job.company}</p>
<p><b>Location:</b> ${job.location}</p>
<p><b>Salary:</b> ${job.salary}</p>

<button onclick="applyJob(${job.id})">Apply</button>
`;

container.appendChild(div);

});

}


/* =============================
   SEARCH JOBS
============================= */

function searchJobs() {

const search = document.getElementById("searchJob").value.toLowerCase();

const jobs = document.querySelectorAll(".jobCard");

jobs.forEach(job => {

const text = job.innerText.toLowerCase();

job.style.display = text.includes(search) ? "block" : "none";

});

}


/* =============================
   APPLY JOB
============================= */

function applyJob(jobId) {

localStorage.setItem("selectedJob", jobId);

window.location = "apply.html";

}


/* =============================
   POST JOB
============================= */

async function postJob() {

const title = document.getElementById("title").value;
const company = document.getElementById("company").value;
const location = document.getElementById("location").value;
const salary = document.getElementById("salary").value;
const description = document.getElementById("description").value;

await fetch("http://localhost:5000/jobs", {

method: "POST",

headers: {
"Content-Type": "application/json"
},

body: JSON.stringify({
title,
company,
location,
salary,
description
})

});

alert("Job posted successfully");

showJobs();

}


/* =============================
   SKILL MATCHING
============================= */

function matchJobs(userSkills, jobs) {

userSkills = userSkills.toLowerCase().split(",");

return jobs.filter(job => {

const description = job.description.toLowerCase();

return userSkills.some(skill =>
description.includes(skill.trim())
);

});

}


/* =============================
   THEME TOGGLE
============================= */

function toggleTheme() {

document.body.classList.toggle("dark");

localStorage.setItem(
"theme",
document.body.classList.contains("dark") ? "dark" : "light"
);

}


/* =============================
   LOAD THEME ON PAGE LOAD
============================= */

window.onload = function () {

if (localStorage.getItem("theme") === "dark") {

document.body.classList.add("dark");

}

};