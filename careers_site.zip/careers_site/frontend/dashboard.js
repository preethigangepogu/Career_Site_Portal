/* =============================
   LOAD DASHBOARD DATA
============================= */

async function loadDashboard(){

try{

const res = await fetch("http://localhost:5000/jobs")
const jobs = await res.json()

/* Total Jobs */

document.getElementById("totalJobs").innerText = jobs.length

/* Show recent jobs */

showRecentJobs(jobs)

/* Analyze skill demand */

analyzeSkills(jobs)

}
catch(error){

console.error("Dashboard loading error:", error)

}

}


/* =============================
   RECENT JOBS
============================= */

function showRecentJobs(jobs){

const container = document.getElementById("recentJobs")

container.innerHTML = ""

jobs.slice(-5).forEach(job => {

const div = document.createElement("div")

div.className = "jobCard"

div.innerHTML = `
<h3>${job.title}</h3>
<p><b>Company:</b> ${job.company}</p>
<p><b>Location:</b> ${job.location}</p>
`

container.appendChild(div)

})

}


/* =============================
   SKILL DEMAND ANALYSIS
============================= */

function analyzeSkills(jobs){

const skillsCount = {}

jobs.forEach(job => {

if(!job.description) return

const words = job.description.toLowerCase().split(" ")

words.forEach(word => {

if(word.length > 4){

skillsCount[word] = (skillsCount[word] || 0) + 1

}

})

})

const labels = Object.keys(skillsCount).slice(0,6)
const data = Object.values(skillsCount).slice(0,6)

createChart(labels, data)

}


/* =============================
   CREATE CHART
============================= */

let chartInstance = null

function createChart(labels, data){

const ctx = document.getElementById("skillsChart")

/* Destroy previous chart if exists */

if(chartInstance){
chartInstance.destroy()
}

chartInstance = new Chart(ctx,{

type: "bar",

data: {

labels: labels,

datasets: [{

label: "Skill Demand",

data: data,

backgroundColor: "#00c896"

}]

},

options: {

responsive: true,

plugins:{
legend:{
display:true
}
}

}

})

}


/* =============================
   START DASHBOARD
============================= */

loadDashboard()