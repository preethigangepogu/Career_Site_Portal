const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

/* =============================
   DATABASE CONNECTION
============================= */

const db = new sqlite3.Database("./careers.db", (err) => {
    if (err) {
        console.error("Database connection error:", err.message);
    } else {
        console.log("Connected to SQLite database.");
    }
});

/* =============================
   CREATE TABLES
============================= */

db.run(`
CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    company TEXT,
    location TEXT,
    salary TEXT,
    description TEXT
)
`);

db.run(`
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    password TEXT,
    role TEXT
)
`);

db.run(`
CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    jobId INTEGER,
    name TEXT,
    email TEXT
)
`);

/* =============================
   TEST ROUTE
============================= */

app.get("/", (req, res) => {
    res.send("Careers API Running");
});

/* =============================
   JOB ROUTES
============================= */

// Add job
app.post("/jobs", (req, res) => {

    const { title, company, location, salary, description } = req.body;

    if (!title || !company) {
        return res.status(400).json({ error: "Missing job information" });
    }

    const sql = `
    INSERT INTO jobs (title, company, location, salary, description)
    VALUES (?, ?, ?, ?, ?)
    `;

    db.run(sql, [title, company, location, salary, description], function (err) {

        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json({
            message: "Job posted successfully",
            jobId: this.lastID
        });

    });

});

// Get all jobs
app.get("/jobs", (req, res) => {

    db.all("SELECT * FROM jobs", [], (err, rows) => {

        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(rows);

    });

});

/* =============================
   AUTH ROUTES
============================= */

// Register user
app.post("/register", (req, res) => {

    const { name, email, password, role } = req.body;

    if (!name || !email || !password || !role) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    db.run(
        "INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)",
        [name, email, password, role],
        function (err) {

            if (err) {
                return res.status(500).json({ error: err.message });
            }

            res.json({
                message: "User created successfully",
                userId: this.lastID
            });

        }
    );

});

// Login
app.post("/login", (req, res) => {

    const { email, password } = req.body;

    db.get(
        "SELECT * FROM users WHERE email=? AND password=?",
        [email, password],
        (err, user) => {

            if (err) {
                return res.status(500).json({ error: err.message });
            }

            if (!user) {
                return res.json({ error: "Invalid login credentials" });
            }

            res.json({
                message: "Login successful",
                role: user.role,
                name: user.name
            });

        }
    );

});

/* =============================
   APPLICATION ROUTES
============================= */

// Apply for job
app.post("/apply", (req, res) => {

    const { jobId, name, email } = req.body;

    if (!jobId || !name || !email) {
        return res.status(400).json({ error: "Missing application data" });
    }

    db.run(
        "INSERT INTO applications (jobId,name,email) VALUES (?,?,?)",
        [jobId, name, email],
        function (err) {

            if (err) {
                return res.status(500).json({ error: err.message });
            }

            res.json({
                message: "Application submitted successfully",
                applicationId: this.lastID
            });

        }
    );

});

// Get all applications (for admin/company dashboard)
app.get("/applications", (req, res) => {

    db.all("SELECT * FROM applications", [], (err, rows) => {

        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(rows);

    });

});

// Get applications for a specific job
app.get("/jobs/:id/applications", (req, res) => {

    const jobId = req.params.id;

    db.all(
        "SELECT * FROM applications WHERE jobId=?",
        [jobId],
        (err, rows) => {

            if (err) {
                return res.status(500).json({ error: err.message });
            }

            res.json(rows);

        }
    );

});

/* =============================
   START SERVER
============================= */

app.listen(5000, () => {
    console.log("Server running on port 5000");
});