/* =============================
   STORE JOB ID WHEN APPLY CLICKED
============================= */

function applyJob(jobId){

localStorage.setItem("selectedJob", jobId)

window.location = "apply.html"

}


/* =============================
   SUBMIT APPLICATION
============================= */

async function submitApplication(){

const jobId = localStorage.getItem("selectedJob")

const name = document.getElementById("name").value
const email = document.getElementById("email").value

if(!name || !email){

alert("Please fill all fields")

return

}

try{

await fetch("http://localhost:5000/apply",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
jobId,
name,
email
})

})

alert("Application submitted successfully!")

/* Clear stored job id */

localStorage.removeItem("selectedJob")

/* Reset form */

document.getElementById("name").value=""
document.getElementById("email").value=""

}
catch(error){

alert("Failed to submit application")

}

}